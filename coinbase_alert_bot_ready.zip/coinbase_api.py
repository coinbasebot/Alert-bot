import requests

def get_top_coin_prices():
    url = "https://api.coinbase.com/v2/exchange-rates?currency=USD"
    try:
        response = requests.get(url)
        data = response.json()
        rates = data["data"]["rates"]
        top_coins = ["ETH", "SOL", "ADA", "AVAX", "MATIC", "LINK", "DOGE", "SHIB", "LTC", "PEPE"]
        prices = {coin: 1/float(rates[coin]) for coin in top_coins if coin in rates}
        return prices
    except Exception as e:
        print("Error fetching data:", e)
        return {}