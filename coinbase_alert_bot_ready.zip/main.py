import requests
import time
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_USER_ID
from coinbase_api import get_top_coin_prices

def send_telegram_message(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_USER_ID, "text": message}
    try:
        requests.post(url, json=payload)
    except Exception as e:
        print("Error sending message:", e)

def monitor_market():
    print("🚀 Monitoring started...")
    last_prices = {}
    while True:
        prices = get_top_coin_prices()
        for coin, price in prices.items():
            if coin in last_prices:
                change = (price - last_prices[coin]) / last_prices[coin] * 100
                if change >= 5:
                    send_telegram_message(f"📈 {coin} is up {change:.2f}%!")
            last_prices[coin] = price
        time.sleep(60)  # Check every 1 minute

if __name__ == "__main__":
    send_telegram_message("✅ Bot started and monitoring Coinbase tokens!")
    monitor_market()